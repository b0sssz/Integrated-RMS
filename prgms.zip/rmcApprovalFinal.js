	
	
	// Your web app's Firebase configuration
		// For Firebase JS SDK v7.20.0 and later, measurementId is optional

		var firebaseConfig = {
			apiKey: "AIzaSyAFsv4I5iH09ZsCi0vwlDDFGHconcP6ju4",
			authDomain: "grmas-34b8f.firebaseapp.com",
			databaseURL: "https://grmas-34b8f-default-rtdb.firebaseio.com",
			projectId: "grmas-34b8f",
			storageBucket: "grmas-34b8f.appspot.com",
			messagingSenderId: "35768824628",
			appId: "1:35768824628:web:79d0c93354bc317627eb61",
			measurementId: "G-Z5208G6DXT"
		};

		// Initialize Firebase
		firebase.initializeApp(firebaseConfig);
		firebase.analytics();
		const auth = firebase.auth();
		const db = firebase.firestore();
        var User ;
	

        var srcData = "";
        var srcData2 = "" ;
        var userID = sessionStorage.getItem("userIDF");
        var reportID = sessionStorage.getItem("FinalReportID");
        var srcEncoded;
        var srcEncodedStamp;


genbutton = document.getElementById("save_button");
try {
    
 

        genbutton.addEventListener('click', function(e) { 
            if(User){


                 if(srcData == "" || srcData2 == ""){

                    alert("Please select your signature and stamp image !" );	
 
                 }else{

   
                    DateReport = document.getElementById("ApprovedDate_input");
                    RMCNote = document.getElementById("RMCnote_input");
                    RMCSignURL= srcData;
                    RMCStampURL= srcData2;
                    RMCStatus = "Approved";
               
                   // console.log("fileId : " + User.uid);
                   // console.log("fileId : " + userID);
                   // console.log("fileId : " + reportID);
                   
               
                

                    var rmcupdate = db.collection('FinalReport/'+'UserID/' + userID).doc(reportID);

                

                    rmcupdate.update({
			
               
             
                        RMC_Note : RMCNote.value.toUpperCase(),
                        RMC_AppDate : DateReport.value.toUpperCase(),
                        RMCSignURL :  srcEncoded,
                        RMCStampURL : srcEncodedStamp,
                        RMC_Status : RMCStatus
                    
                      }).then(() => {


                        console.log("success" );
                

                        window.location.href = 'rmcVFinal.html';
            
                    });
                    };

            

                    
                    


                  //  
                }else{
                    alert('Please Sign In');
                    window.location.href = 'home.html';
                };
        });
    

    }
    catch(err) {
      alert('Please fill all the form correctly');
    };
    //---------------------------------------Convert to basee64--------------------------------------------------------------------------//

    function encodeImageFileURL(){
        fileSelect = document.getElementById("ImageFile").files;
     
    
    
        if (fileSelect.length > 0 ){
            var fileSelect = fileSelect[0];
            var fileReader = new FileReader();

          
    
            fileReader.onload = function(FileLoadEvent){
                srcData = FileLoadEvent.target.result;
                process();
            }
            fileReader.readAsDataURL(fileSelect)

     
        }
    }
    

    function process() {
        const file = document.querySelector("#ImageFile").files[0];
      
        if (!file) return;
      
        const reader = new FileReader();
      
        reader.readAsDataURL(file);
      
        reader.onload = function (event) {
          const imgElement = document.createElement("img");
          imgElement.src = event.target.result;
          //document.querySelector("#input").src = event.target.result;
      
          imgElement.onload = function (e) {
            const canvas = document.createElement("canvas");
            const MAX_WIDTH = 400;
      
            const scaleSize = MAX_WIDTH / e.target.width;
            canvas.width = MAX_WIDTH;
            canvas.height = e.target.height * scaleSize;
      
            const ctx = canvas.getContext("2d");
      
            ctx.drawImage(e.target, 0, 0, canvas.width, canvas.height);
      
            srcEncoded = ctx.canvas.toDataURL(e.target, "image/jpeg");
      
            // you can send srcEncoded to the server
           // console.log(srcEncoded)
          };
        };
      }
    
    
    function encodeImageStampFileURL(){
        fileSelectStamp = document.getElementById("StampFile").files;
    
    
        if ( fileSelectStamp.length > 0 ){
    

            var fileSelectStamp = fileSelectStamp[0];
            var fileReaderStamp = new FileReader();
    
     

            fileReaderStamp.onload = function(FileLoadEventStamp){
                srcData2 = FileLoadEventStamp.target.result;             
                processStamp();
            }
            fileReaderStamp.readAsDataURL(fileSelectStamp)
        }
    }
    

    function processStamp() {
        const file = document.querySelector("#StampFile").files[0];
      
        if (!file) return;
      
        const reader = new FileReader();
      
        reader.readAsDataURL(file);
      
        reader.onload = function (event) {
          const imgElement = document.createElement("img");
          imgElement.src = event.target.result;
          //document.querySelector("#input").src = event.target.result;
      
          imgElement.onload = function (e) {
            const canvas = document.createElement("canvas");
            const MAX_WIDTH = 400;
      
            const scaleSize = MAX_WIDTH / e.target.width;
            canvas.width = MAX_WIDTH;
            canvas.height = e.target.height * scaleSize;
      
            const ctx = canvas.getContext("2d");
      
            ctx.drawImage(e.target, 0, 0, canvas.width, canvas.height);
      
            srcEncodedStamp = ctx.canvas.toDataURL(e.target, "image/jpeg");
      
            // you can send srcEncoded to the server
           //console.log(srcEncodedStamp)
          };
        };
      }

    var ImageFile= document.getElementById("ImageFile");
    ImageFile.addEventListener("change",function(){
        encodeImageFileURL();
    })
    var StampFile= document.getElementById("StampFile");
    StampFile.addEventListener("change",function(){
        encodeImageStampFileURL();
    })
    
    
    

//---------------------------------------Auth state Changed--------------------------------------------------------------------------//
auth.onAuthStateChanged(user => {
	if (user) {
		
		User = user;	
		


	}else{
		console.log('user logged out');
	}
});

//---------------------------------------Drag and drop--------------------------------------------------------------------------//

document.querySelectorAll(".containerfile_input").forEach(inputElement =>{
 
	const dropzoneElement = inputElement.closest(".containerfile");
   


	dropzoneElement.addEventListener("click", e =>{
		inputElement.click();
	});

	inputElement.addEventListener("change", e=>{
		if (inputElement.files.length) {
			Folder =  e.target.files;
        
			
			for (let i = 0; i < Folder.length; i++) {
				updateThumbnail(dropzoneElement, inputElement.files[0]);
				
			}
		}
	});

	dropzoneElement.addEventListener("dragover", e =>{
		e.preventDefault();
		dropzoneElement.classList.add("containerfile--over");
	});

	["dragleave","dragend"].forEach(type =>{
		dropzoneElement.addEventListener(type, e =>{
			dropzoneElement.classList.remove("containerfile--over");
		});
	});

	dropzoneElement.addEventListener("drop", e =>{
		e.preventDefault();

		if (e.dataTransfer.files.length) {
			
            inputElement.files = e.dataTransfer.files;
            Folder =  inputElement.files;
            for (let i = 0; i < Folder.length; i++) {
			updateThumbnail(dropzoneElement, e.dataTransfer.files[0]);
				
			}

		}

		dropzoneElement.classList.remove("containerfile--over");
	});
});

function updateThumbnail(dropzoneElement, file){
	let thumbnailElement = dropzoneElement.querySelector(".containerfile_thumb");
   
	//console.log(file);
   


	if (dropzoneElement.querySelector(".containerfile_prompt")) {
		dropzoneElement.querySelector(".containerfile_prompt").style.display = 'none';
	}
	//first time, there no thumbnail element, lets create
	if (!thumbnailElement) {
		thumbnailElement = document.createElement("div");
		thumbnailElement.classList.add("containerfile_thumb");
		dropzoneElement.appendChild(thumbnailElement);
		
	}

	thumbnailElement.dataset.label = file.name;

	//show thumnail image file
	for (let i = 0; i < Folder.length; i++) {
		if (file.type.startsWith("image/")) {
			const reader = new FileReader();
	
			reader.readAsDataURL(file);
            

			reader.onload =  ()=>{
				thumbnailElement.style.backgroundImage = `url('${reader.result}')`;
               


			};
	
			
		}else
		{
			thumbnailElement.style.backgroundImage = null;
		}
	}
}

const bar = document.querySelector('.progress');
const uploadfile = document.getElementById("upload_button");

	

//---------------------------------------Log Out Account--------------------------------------------------------------------------//
 
           
LogOut.addEventListener('click', function(e) {
    e.preventDefault();
    auth.signOut().then(() => {
        (e => alert(e.message));
        alert("Sign Out" );	
        window.location.href = 'home.html';
    })			
                        
                        
            });
















