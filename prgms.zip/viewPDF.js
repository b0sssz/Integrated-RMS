	
	
	// Your web app's Firebase configuration
		// For Firebase JS SDK v7.20.0 and later, measurementId is optional

		var firebaseConfig = {
			apiKey: "AIzaSyAFsv4I5iH09ZsCi0vwlDDFGHconcP6ju4",
			authDomain: "grmas-34b8f.firebaseapp.com",
			databaseURL: "https://grmas-34b8f-default-rtdb.firebaseio.com",
			projectId: "grmas-34b8f",
			storageBucket: "grmas-34b8f.appspot.com",
			messagingSenderId: "35768824628",
			appId: "1:35768824628:web:79d0c93354bc317627eb61",
			measurementId: "G-Z5208G6DXT"
		};

		// Initialize Firebase
		firebase.initializeApp(firebaseConfig);
		firebase.analytics();
		const auth = firebase.auth();
		const db = firebase.firestore();
		var storage = firebase.storage();
		var fileref = storage.ref();
		db.settings({timestampsInSnapshots : true})
        var User;

    

var reportID = sessionStorage.getItem("reportID");
var LogOut = document.getElementById("LogOut");

window.onload = function () {
const repPdf = document.querySelector('.row');
auth.onAuthStateChanged(user => {
	if (user) {
       // console.log(reportID);
		
			
	 db.collection('ReportProgress/'+'UserID/' + user.uid ).doc(reportID).get().then(function(doc) {
			
                        const html = `
                            
                            
                            <div class="row">
                            <div class="col-md-12 text-right mb-3">
                                <button class="btn btn-primary" id="download"> Download PDF</button>
                            </div>
                            <div class="col-md-12"id="invoice" style="padding-top:30px; ">
                            <p>
                        
                            </p>
                                <div class="card" >
                                <div class=" bg-transparent header-elements-inline">
                                <div> <img style="height: 55px;" src="data:image/jpeg;base64,/9j/4AAQSkZJRgABAQEAeAB4AAD/2wBDAAgGBgcGBQgHBwcJCQgKDBQNDAsLDBkSEw8UHRofHh0aHBwgJC4nICIsIxwcKDcpLDAxNDQ0Hyc5PTgyPC4zNDL/2wBDAQkJCQwLDBgNDRgyIRwhMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjL/wAARCADJAbADASIAAhEBAxEB/8QAHwAAAQUBAQEBAQEAAAAAAAAAAAECAwQFBgcICQoL/8QAtRAAAgEDAwIEAwUFBAQAAAF9AQIDAAQRBRIhMUEGE1FhByJxFDKBkaEII0KxwRVS0fAkM2JyggkKFhcYGRolJicoKSo0NTY3ODk6Q0RFRkdISUpTVFVWV1hZWmNkZWZnaGlqc3R1dnd4eXqDhIWGh4iJipKTlJWWl5iZmqKjpKWmp6ipqrKztLW2t7i5usLDxMXGx8jJytLT1NXW19jZ2uHi4+Tl5ufo6erx8vP09fb3+Pn6/8QAHwEAAwEBAQEBAQEBAQAAAAAAAAECAwQFBgcICQoL/8QAtREAAgECBAQDBAcFBAQAAQJ3AAECAxEEBSExBhJBUQdhcRMiMoEIFEKRobHBCSMzUvAVYnLRChYkNOEl8RcYGRomJygpKjU2Nzg5OkNERUZHSElKU1RVVldYWVpjZGVmZ2hpanN0dXZ3eHl6goOEhYaHiImKkpOUlZaXmJmaoqOkpaanqKmqsrO0tba3uLm6wsPExcbHyMnK0tPU1dbX2Nna4uPk5ebn6Onq8vP09fb3+Pn6/9oADAMBAAIRAxEAPwD3+iiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKQ8DNLRQBmanr2k6MiPqeo21mJOE8+QKW+mazf+E+8I/9DHpv/f8AWvAvjTLJJ8S7tJHLLHDEqKTwo25wPxJrz0gZ6Vi6tnY9KlgFOCk3ufYH/Ce+Ef8AoY9N/wC/60+Lxv4WnmSKLxBpzSOdqqLheT6V8eYo7YxS9q+xby6Pc+4wQQMUtcx8PZpbj4faDLNI0kjWiZZjknHFdMK2Tujy5LlbQtFFFMQUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRTd6A/fX86PMT++v50Dsx1FN8xP76/nR5if31/OgLMdRTfMT++v50m9SMB1/OgVmfLvxlP/FzdQ/65xf8AoArga9k+Jnw98U6/46vNR0zSzPaSJGFkEqDJC4PBNcj/AMKk8cdtEb/v9H/8VXLKLvoj3aFamqaTkcTijB9K7b/hUnjn/oCP/wB/o/8A4qnxfCDxvNKsZ0jy9xxvedAq+5waXLLsavEUv5j6A+G//JONA/69F/rXUisnwzpDaD4a03SWl81rW3WNnAwGI6n861q6lsfPzacm0LRRRTJCiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigBD0ry74q+J77TpbbSLGZ7cSxGSaRDhiM4Cg9u+a9RNeJfGD/AJGq0/69B/6EazqtqOh6OVU41MUlNXWpwJnmJyZ5SfUyGjzpf+e0v/fZplFcd2fZ8kV0H+dL/wA9pf8Avs0edL/z2l/77NMoouw5Y9h/nS/89pf+/hqeyml/tC1HnS/65P4z/eFVansv+Qja/wDXZP8A0IUJu5FSEeR6H1KBgfhTh0pvYfSn16B+fdQooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAQ9K8S+MH/I12v/XmP/QjXt1eI/GD/karX/r0H/oRrKt8DPVyb/el6M8+ooorjPsXuFFFFABU9l/yELX/AK7J/wChCoKnsv8AkIWv/XZP/QhTW5FT4GfUvYfSn0zsKcK9A/PBaKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooqjqmq2uj2pubyXZHnAAGSx9APWgC9RXFR/EewaYK9ncpGT9/KnH4V11pdQXttHc20olhkGVYdDQBPRRRQAUUUUAFFZms67ZaJbCW7kIZzhI0GWY+w/rXP23xF06SYJPbXEKE4Ehw2PqBQB2dFRxSpNGskbh43G5WB4INSUAFFIelV729t7C2a5u7iOCBBlpJGwBQNJt2RZorz2/+Luh2rslrDdXhB+8ihFP0J/wqh/wuiz/AOgLc/8Af5ah1ILqdkcuxUldQZ6jRXl3/C6LP/oCXP8A3+Wj/hdFn/0BLn/v8tL2sO5X9mYv+T8j1GivLj8aLT/oC3I/7bLWi/xPt08GXniX+zLjyrW4WAweauWLEc5/GmqkXszOpgMRSV5xsegUV4v/AMNDaf8A9C/d/wDgQv8AhR/w0Np//Qv3f/gQv+FHtI9yPqtb+U9nPSvNfif4RvtXa31XTozPLDGY5YV+8VzkFfXHPFYX/DQunngeH7v/AMCF/wAK9F8MeMNN8VeHhrVqzQwoSsyTYBiYDkHt3HND5ZqxdJ18JUVVKx4AdH1QMQdMvQR2+zt/hSf2Rqf/AEDb3/wHb/Cvb7n4i6fFKUt7WedBxvyFB+mai/4WVbf9A2f/AL+LWf1ddz1f9YKn8n4niv8AZOp/9A29/wDAdv8ACj+ydT/6Bt7/AOA7f4V7V/wsq2/6Bs//AH8Wj/hZVt/0DZ/+/i0fV13D/WCp/J+J4r/ZGp/9A29/8B3/AMK6Lwl4I1XVtYtpLizntrGKRXllmQpuAOcKD1J/SvR/+Fk23/QNn/7+LR/wsi1/6Bk//fxaaoJO9zKrnlWcHFRSudvjiniuF/4WTbf9A2f/AL+LS/8ACyrb/oGz/wDfxa2seIdzRXDf8LKtv+gbP/38Wj/hZVt/0DZ/+/i07AdzRWNoniSw11WFszJMgy8UgwwHr7itd3CKWZgqgZJJ4FIB1Fcvf+O9HsnaON5Lpx/zxX5fzPFZ3/Cyrb/oGz/9/FoA7miuG/4WVbf9A2f/AL+LR/wsq2/6Bs//AH8WnYDuaK4b/hZVt/0DZ/8Av4tH/Cyrb/oGz/8AfxaLAdzRXER/EmzZgJLC5Re5DK1dBpfiPTNYO20uQZcZ8pxtf8u/4UgNeisPVPFelaS5jmufMmHWKEbmH17CsNviTaBsLp1wR6l1FAHcUVw3/Cyrb/oGz/8AfxaP+FlW3/QNn/7+LTsB3NFcN/wsq2/6Bs//AH8Wj/hZVt/0DZ/+/i0WA7miuGHxKtc86dcAezrWvp3jPR9RkWITm3lbgLONufoelIDoqKMj1ooAQ9K84+JEjnVLKIk7FhLAe5OD/KvRz0rzX4kf8hmz/wCvc/8AoRpoDja9J+G8jtpF3GWyqT/KPTIGa82r0f4bf8g2+/67D/0GhgdtRRRSAKQ9KWq99dJZWFxcueIo2c/gKAPKfGd8b7xLcANmODEK/h1/WsCnSSNNI8rnLOxZj7nmhEaWRY0GWdgqj3NUI9Y8D+aPCtr5pPV9n+7u4ros1X0+0WxsLe1QfLDGE/IVYNSMp6nqVvpWmXF9dtsggQs5/p9a+ePE3ii/8Uai1xdOVt1P7i3B+WMf1PvXpHxiv3h0awsUJC3Exd/cKOB+ZH5V45XNXlryn0+SYSKh7d7vYKKACWCgEknAA716TpPwgvbuzSbUNQFpI4z5KR7yv1OetZRjKWx6+IxdHDpe0djzaivWf+FLJ/0HJP8AwHH+NH/Clk/6Dkn/AIDj/Gq9jM5f7Xwn834P/I8mrp5/+SG63/2EYv5pXYn4LoOmuSf+A4/xqn428JN4Y+EOrWcVy93uuYp2by9u0blB6duKqNOUdWceNzDD14KFOV3ddz5+oo/GipAK9p+HYl/4VBq3lZx/aP7zH93CZ/pXi1fRnwJg3eArwTRZimvXwGHDjaoP1HUVpS+I4sf/AAjmqK9Nufh5pc0xkhmuIFPPlqQQPpnmof8AhW1j/wA/91+S/wCFdNzwzziivR/+FbWP/P8A3X5L/hR/wrax/wCf+6/Jf8KdwPOKK0Nc09NK1m4sY3aRIiAGbqcgGs+i4BRXbaF4ItNW0a3vZLu4jeUElUAwMEjvWj/wrax/5/7r8l/wouB5xRXo/wDwrax/5/7r8l/wo/4VvY5/4/7r8l/wouByvg7zR4ptDHwF3GQ9gmDnP6VP4p8Tzazcvb27lLBGwqg48w/3j7egrpNY0qz8LeFL02Kt504ETTOcsQTz9BjNeb0AFFXNL02bVtRhsoMB5D949FA5JruV+G1nsG/ULkt3KqoFFwPOqK9H/wCFbWP/AD/3X5L/AIUf8K2sf+f+6/Jf8KLgecUV6P8A8K2sf+f+6/Jf8KP+FbWP/P8A3X5L/hRcDzilVmRwysVZeQQcEV22r/D/AOx2ElzY3UkrRLuaKRR8wHXBHeuIHTNAB6+/eilALMFAyScAeprvbL4cI9srXt7KszDLJEowvtk9aAOBor0f/hW1j/z/AN1+S/4Uf8K2sf8An/uvyX/Ci4HnFFej/wDCtrH/AJ/7r8l/wo/4VtY/8/8Adfkv+FFwPOKMetehzfDe28s+TqE4kx8u9AVz74rgru1lsrya1nAEsTlGA6ZFFwOs8HeKpbS5j02+kL28h2xO55jPYZ9P5V6UDkV4Hz26+vpXtuh3bX2h2Vy5y0kKlj6nGDSYy+elea/Ej/kM2f8A17n/ANCNelHpXmvxI/5DNn/17n/0I0IDja9H+G3/ACDb7/rsP/Qa84r0P4dTRR6deiSREJmGNzAfw0MDuqKh+1W//PxF/wB9ij7Vb/8APxF/32KQE1cn4/vvs3h/7OD89zIE/wCAjk/yFdN9qt/+fiL/AL7FeaeP9QW71qK3jcNHbx/wnI3Nyf0xQBydb3g6x+3eJrUEZSHMzfh0/XFYNeg/Diy2295fsPvsIlPsOT+pH5VQjvKQ0uaQ1Izyf4z9NH+sn9K8pr1b4z9NH+sn9K8prjrfGz7TKP8AdI/P8y/oQB8QaaCAR9qj4/4EK+nwMNXzDoX/ACMOm/8AX1H/AOhCvp7vWmH2Z5Wf/wASHzFoooroPACoZoI543jmRZI2GGRhkMPQjuKmooA4vW/CPhXTdFvtQj8M6W8kELShWgGCQM9q8o/4SbSMf8iPoH/fo17h4tA/4RDV/wDr0k/lXzUOg+lc9aTi9D6DJ8PTrwk6ivZ92dL/AMJLpH/Qj6B/36NeufD3XDrvh95fsNtZRwTGFIbYYQAAHp+NfP4617V8Hv8AkVrv/r7b/wBBWlSm3KzNc2wdGlQ54LW67noo6UUUV0nzQUUUUAePeMP+Rrvv95f/AEEVh1ueMP8Aka77/eX/ANBFYdUhHr3gv/kVLL6N/wChGt+sDwX/AMipZfRv/QjW/UjCiiigDlviB/yK7f8AXZK8rr1T4gf8iu3/AF2SvK6pCOk8B/8AI1w/9cn/AJV6zXk3gP8A5GuH/rk/8q9ZpMYUUUUgCiiigCC9/wCPC4/65N/I14QOgr3e9/48Lj/rk38jXhI6U0BLa/8AH5B/10X+Yr3ivB7X/j8g/wCui/zFe8UMAooopAFFFFACGvGvFP8AyNGo/wDXb+gr2U1414p/5GnUf+u39BTQGRXsfhL/AJFTTv8Arl/U145XsfhL/kVNO/65f1NDA2T0rzX4kf8AIZs/+vc/+hGvSj0rzX4kf8hmz/69z/6EaEBxtGM9aKuWelX+oIz2dnNOqnDGNc4NMRS2j0o2j0rV/wCEb1v/AKBV1/3xR/wjet/9Aq6/74oAyto9KXArU/4RvW/+gVdf98Uf8I3rf/QKuv8AvigDLqzaaheWEge0upYSP7jYH4jpVpvDmtKCTpV1gf7FZrKysVZSrKcEEYINAHovhjxqb6aOy1MIlw3EcyjCufQjsf512ucivBOeoOCOQa9l8M6k2q6Ba3MhzLjZIfVhwT+PWkwPPvjP00f6yf0rymvVvjP00f6yf0rymuKt8bPtco/3SPz/ADNDQf8AkYtN/wCvqP8A9CFfT3evlezuWsr63ukG5oZVkAPfBBr6K0jxfomsWiXMOowISvzRSOFZD6EGroNao87PqU3KEktNTfoql/bGl/8AQRtP+/6/40f2xpf/AEEbT/v+v+NdF0fPckuxdoql/bGmf9BG0/7/AK/40f2xpn/QRtP+/wCv+NO6Dkl2KPi0/wDFH6v/ANekn/oNfNS/dH0r3Hx/4y0y18P3en211Fc3l1GYgkTBgoPUnHSvD+nArlrtN6H1GR05wpScla7DvXtXwe/5Fa7/AOvs/wDoK14rXt3wgiaPwlM7DiS6cr74AH9KVD4jTO3/ALL80eg0UdqK6z5EKKKKAPHvGH/I133+8v8A6CKw63PGH/I133+8v/oIrDqkI9e8F/8AIqWX0b/0I1v1geC/+RUsvo3/AKEa36kYUUUUAct8QP8AkV2/67JXldeqfED/AJFdv+uyV5XVIR0ngP8A5GuH/rk/8q9ZrybwH/yNcP8A1yf+Ves0mMKKKKQBRRRQBBe/8eFx/wBcm/ka8JHSvdr3/jwuP+uTfyNeEjpTQEtr/wAfkH/XRf5iveK8Htf+PyD/AK6L/MV7xQwCiiikAUUUUAIa8a8U/wDI06j/ANdv6CvZTXjXin/kadR/67f0FNAZFex+Ev8AkVNO/wCuX9TXjlex+Ev+RU07/rl/U0MDZPSvNfiR/wAhmz/69z/6Ea9KPSvNfiR/yGbP/r3P/oRoQHG16N8N/wDkG33/AF2H/oNec16P8Nv+Qbff9dh/6DQwO1x70Y96WikAmPejHvS0UAJivKfHsaJ4ocqoBeFGbHc8jNer15X4/wD+RnP/AFwT+tNActXp3w7OfDsntct/IV5jXp3w7/5F6X/r5b+QoYjlfjP00f6yf0rymvVvjP00f6yf0rymuKt8bPtco/3SPz/MKTaD1AP1FXtP0fUtWaRdOsprpo8FxEuduelXv+EN8T/9AK+/791Ci3sjtlXpRfLKSXzRhbE/uj8qNif3R+Vbv/CG+Jv+gFff9+6P+EN8Tf8AQCvv+/f/ANejkl2J+tYf+dfejC2J/dH5UbE/uj8q3f8AhDfE3/QCvv8Av3/9ej/hDfE3/QCvv+/dHLLsH1rD/wA6+9GGAB0AH0pa3B4M8Tk/8gK9/wC/f/1619M+F/iW/kXz4I7GLu87gn/vkf8A1qOST6EzxuHgrua++5ylhY3Op38NlZxmS4mYKij+Z9hX0l4f0mLQtEtdNiIIgQBm/vN3P4ms3wr4L03wtF+4Uz3TjElzIPmPsB2FdNgeldVKny7ny+Z5h9akow+FfiL2ooorU8oKKKKAPHvGH/I133+8v/oIrDrc8Yf8jXff7y/+gisOqQj17wX/AMipZfRv/QjW/WB4L/5FSy+jf+hGt+pGFFFFAHLfED/kV2/67JXldeqfED/kV2/67JXldUhHSeA/+Rrh/wCuT/yr1mvJvAf/ACNcP/XJ/wCVes0mMKKKKQBRRRQBBe/8eFx/1yb+RrwkdK92vf8AjwuP+uTfyNeEjpTQEtr/AMfkH/XRf5iveK8Htf8Aj8g/66L/ADFe8UMAooopAFFFFACGvGvFP/I06j/12/oK9lNeNeKf+Rp1H/rt/QU0BkV7H4S/5FTTv+uX9TXjlex+Ev8AkVNO/wCuX9TQwNk9K81+JH/IZs/+vc/+hGvS684+JEMg1Gxn2ny2iKA+4Of60IDia9H+G3/INvv+uw/9BrzivSvhxC6aPcysMJJN8h9cDBP50MDs6KKKQBRRRQAV5X4//wCRnP8A1wT+teqV5d8QoZE8QxzMuI5IAFb1wTmmgZydem/Dv/kXZf8Ar5b+QrzKvUvAEMkXhre6lRLMzpnuOBn9KHsI5H4z/wDMH+sn9K8pr1r4y28rW2lXCqTEkjozehIGP5GvJa4q3xn2mUNfVI/M9Q+DI/0zV/8Acj/ma9dxXk/wat5R/at0VIiYxxqxHUjJP8xXrIropfAj53NXfFzDFGKWitDzhMUYpaKAEx70YpaKAExzS0UUAFFFFABRRQelAHj3jD/ka77/AHl/9BFYddB41hki8VXRdcCQK6H1GMf0rn88fSqQj17wX/yKll9G/wDQjW/WJ4RheDwvYpIu1thbB9CSR+lbdSMKKKKAOW+IH/Irt/12SvK69X8dQvN4XnMak+XIjtj0B5P615RTQjpPAf8AyNcP/XJ/5V6zXlXgGF5PEvmKpKRQsWPpngV6rQxhRRRSAKKKKAIL3/jwuP8Ark38jXhI6V7xdI0lpMijLMjKPqRXhDI0TtG4KuhKsCOhFNASWv8Ax+Qf9dF/mK94rwvToXudTtYYlLO8qgAfWvcwaGAtFFFIAooooAQ1414p/wCRp1H/AK7f0FeymvHvF0EkHim+3qR5jB146ggU0BiV7H4S/wCRU07/AK5f1NeOdOT2r2fwzC9v4a0+KRSrrCMg9s80MDWqrqGnWmqWrW15CJYm7HsfUHsasnpxVaQX/mHymt9nbeGz+lIDnE+HmjLNvZ7p0Bz5ZkGP5ZrqILeK1hSGCNY4kG1UUYAFV8an/etP++W/xoxqf960/wC+W/xoAu0VSxqf960/75b/ABoxqf8AetP++W/xoAu0VSxqf960/wC+W/xoxqf960/75b/GgC7VLU9Js9XtjBexCRM5B6FT6g9qMan/AHrT/vlv8aMan/etP++W/wAaAMGD4faNFOJHNxMoPEcjjb+OBzXTpGkKKkahUUYVQMACq2NT/vWn/fLf40Y1P+9af98t/jQA6+0+11Kzktb2FJ4JBho3HBriz8I/Dn2nzPMvhHnPledx9M4z+tdljU/71p/3y3+NGNT/AL1p/wB8t/jUuKe6NqWIq0k1Tk1cLDTbTS7OO0soEggjGFRBx/8Ar96uDrVPGp/3rT/vlv8AGjGp/wB60/75b/GqMm23dl2iqWNT/vWn/fLf40Y1P+9af98t/jQIu0VSxqf960/75b/GjGp/3rT/AL5b/GgC7RVLGp/3rT/vlv8AGjGp/wB60/75b/GgC7RVLGp/3rT/AL5b/GjGp/3rT/vlv8aALtFUsan/AHrT/vlv8aMan/etP++W/wAaALtFUsan/etP++W/xoxqf960/wC+W/xoAi1XQrDWoRHexbiv3HU4ZfoaybPwFo1pcCZxNcFTlVmYFfyAGfxrbxqf960/75b/ABoxqf8AetP++W/xoAuAYGKWqWNT/vWn/fLf40Y1P+9af98t/jQBdoqljU/71p/3y3+NGNT/AL1p/wB8t/jQBbZFdSrAFSMEEcGuWufh/o085kQzwAnJjjcbfwyOK3san/etP++W/wAaMan/AHrT/vlv8aAG6Xo9lo9t5FlD5ak5Yk5Zj6k1fqljU/71p/3y3+NGNT/vWn/fLf40AXaKpY1P+9af98t/jRjU/wC9af8AfLf40AXaKpY1P+9af98t/jRjU/71p/3y3+NAFwjIrA1bwdpWr3BuJUkinb7zxNjd9R0rTxqf960/75b/ABoxqf8AetP++W/xoApaP4W0zRHMtvG7zkY82VtzAe3pWyBiqeNT/vWn/fLf40Y1P+9af98t/jQBdoqljU/71p/3y3+NGNT/AL1p/wB8t/jQBdoqljU/71p/3y3+NGNT/vWn/fLf40AXazNX0DT9bjC3kRLL9yRThl/H+lTY1P8AvWn/AHy3+NGNT/vWn/fLf40AY1h4E0exuVnKy3DIcqJmBUH6Ac/jXTAYqtEL3f8Avzb7Mf8ALMMD+tWBQAHpWXb6q8uvX2nsiLHbRRuHzyd2c5rVrgNZju5PEWreSrvaiOA3ccRxI8XOQv8AX2oA6jTtWm1S+la2hT+zY/kW4JOZX77R/dHr3rTmmSCFpZHCRoCzM3QAdTUGnT2c+nwSWBQ2pUCPYOAPT2rM8ZBz4VvNmcAKXx12bhu/TNAEcOr6xqy+dpdlbxWZ+5NeM2ZB6hV5A+tOj128sbuK31q0jhSZtkV1AxaIt2BzypNbNq8LWkJgx5RQbNvTbjisjxi0P/CLXiyfeYARjuXyNuPfNAG6KzIdUkk8S3OlmNBHDbpKHzySTjFXrUOLSES/6wRru+uOawrU48f6h/15R/8AoRoA6OsbXdUu9Pexhs4oZJbqbyh5xIUcZ7VsZzXM+LBM15ogtmRZjefIzglQdp64oAvW8niI3MYuYNNWDd85jkcsB7ZFbAOayLeLXxcxm5u7B4AfnWOFgxHsc1rZA60AMupTBaTTKATHGzAHvgZqro18+p6Pa3siKjzRhiq9BUuoMP7Muv8Ari//AKCaoeE/+RV03/rgKANmkY4GaWkbpQByF14g8QTeKb7SNJtNPZbSKORnuZHUncPbNWNL8SaiddXRdb0+K1u5YzLBJBIXimUdQMgEEVhmfVrf4k64dJsILtza2/mLNP5YUYOCDg5rX03RtavvEkOt66LWD7LE0dra27lwu77zMx6nis02d84QjH3krcvzudRJKIo2d2VVUEsx6ACuSg8S654gd5PDthbJp6khb2/ZgJsd0Rece5q/45SdvBWrLb5Mpt2wB1I7/pmrugy2smgae1kVNsbdPL29MYq3q7HPFRjT52ru9jFbxPq+iXUUfiWwt47SVxGt/ZuWjVj0Dg8rn16V1qMWUHj8K57xtJap4L1Y3e3y2t2UA92P3QPfOK0PDwnTw5pq3WfPFtGJM9c7RSV72CaUqamlZ3sVm1yZfGseh+TH5L2RuTJk7gQ2MfSt2uNkP/F24D/1CW/9DrscimiasVHlt1SMCHXrhfF9xod7DHEGiE9nKpP71ejA57g0l54gnXxTZaJYwRyuyGe7kYnEMfQdO5NV/GlhJJpiavakLfaU/wBqhY8blH30PsRn9KZ4ItJJbCbXrvH27V289sfwR/wIPYD+dTrexryw9n7X5W8/+G1OqBNBY1kavrE2lvGsWkX99vBJNqqkJj1yRVrS79tQsluJLK4tGJI8q4ADjH0Jq7nO4NR5jnvE+ueJdCt7vUIrTTJNOhxtLyP5hBIHIxjqfWtTRbjxDNIz6vBp8cDIGj+yyOzEn1yOmKofEf8A5ETUv91P/QhXRWv/AB6Q/wDXNf5VC+KxvJr2CfKr3a/Iy/FuuT6BoEl/bRRyyrIiBJCQvzMB2+tUkufG7Mpaz0PYcZInkzj8qg+JW7/hDJtpw3nw4JHH3xiporXxn+7J1LR9nGQLV84/76ob96xUIxVFS0u29/l2OpydvOM1zuteJ5bPUI9J0uzN/qsib/K3bUiX+87dhXQnheea43wyUTxn4qjuP+Pxp43XPUw7flx7Zqn2MqMYtSlLWy/Unlv/ABtYx/aZdO0q9jXl4LWV1kx/sluCa29E1u217T1vbTd5bHayOuGRh1Vh2Iq9ldo4psEsEoYwPG4DEMUIPPfOO9FrEympLazMnxFrs2iyaWsUMcgvL1LZ95I2g55HvWreTtb2U86gM0cbOAe+BmuQ+IYnZdBFq6JOdTjEbSLlQ2DjI9Kmv7bxmNPuvN1LRzH5Tbgtq+cYOcfNUt7m6oxcIO6V/wDM2/DOrS654csdTmiSKS4j3lEOQOe1a1c18Pv+RD0j/rh/U10tVHYwrRUakoro2Fc7e+JJbLxNHp0kCfYyEDz5OVZ8hfbGRj8a6KuUurCPU/FGr2Uo+WWwjGfQ7jg/gcGmZnVE4Fc7beJJbrxOdNigQ2mHVZ8nLMgG7Htk4qumvTp4YbcM6qkn2LZ6z9Af/Zqbb2CaX4j0OyQ5EdpNub+8xwSfxNAHW1la9qsul2kZtoRcXk8gjhhJxuPU/gBWoelccdXtpfF01zOJ3gsEMEHlQtIDIfvnIB9hQB0ul6jHqmmW95HgCVclf7rdCPwNXa5Hw7qEEWvX2nRCVba4JubYSxsmCfvqAffmuuoA5iy1fXtSFxJaWun+TFO8I8yRwx2n2FX9K1ia7vZ9PvrUWt7AodkDbldT0ZT6VkaLf/2XoWqXht5J0jv5i6x4yBnrz6VoaRbz3eqya3ciOMSwLFbxxvvwnXcT0yfagDfrntZ8StpmqRW8cAlhQK93Jn/UqxwprcuZ47a3knlbbHGpdj6AVxWmahY3Onag+oxXRm1NmaTbbOwVMYQAgdhQB3IOenPGaWuf8Iag17o4glLG4tD5LlgQSB90kHkZFdBQAVmW+mGDXLzUfNz9pjRPL2/d2579+taRpv8AFQBlWujfYNVkurKfyrabma125Qt/eX+6fX1rWdFkQo4DKwwQehFHcfWlPSgDn00K+00smj6n5NsSSLa4i8xE/wB05BA9qkg0CWe8ivNXvmvZYTmKMJsijPqF7n3NbnekXrQA7GKwbvRb1tbm1Kx1FLZ5YliZWgD8D8a3qYev40AVdOgvoEcX16l0xOVZYhHtHpjNVda0qXU3s5ILoW8trL5qMY94JxjpmtYdaafvGgDKgstajuI3n1eKWINl4xahSw9M54rUaNZY2RxlWBUj1Bp7dKRfuigDmk8O6lDZvptvrJTTnyoVod0qIeqhs/qRXQWdrFZWkVrACIokCKPYVJ3pw6UALSN0paa/3DQBiWmi/ZfFGo6z5+4XkMcXlbfu7M8575rcFQ9hU/ai1hubnq/QZIqsNrAEEYINckvhS/0maRvDmr/YraRixs7iHzoVJ67OQVHt0rrX6im9qGroqnUlG9jlovCl3f30N14i1Q6iIG3xWsUQigVuxK5JYj3rqxwKB1NHY0JWCpOUmrnM6r4c1C68Rx6zpurJZzLbfZ9r24kBGc+orT0m01e183+1NUjvt2Nmy2EW316E5rRXtTu9HKk7lyqScVF9PJFXU7P+0NKu7Pfs8+Fo92M7cjGaj0XTzpWjWenmXzPs0Kxb8Y3YHXFXvWkH9aFuZKTty9AYc5pwHpTX6Uo6ChitZXMrxLpH9v6Dc6WJvJ88D95t3YwQen4VpRJ5cMaddqAfkKc3WlHT8KSXUbk2uXpcx/FGinxDocmni4FuXdHEhTdjawPT8KoJpPipSo/4Sa3Kgjj+zxyPT71dI/3R9aXvT5VuawqSUFHp6IUjIAJzWFrnhmLVbqG/trqWw1SAYju4cZ2/3WB4ZfY1vU09T9KGZQqShK8WcrLoXii+iNvd+JYY7cjDtaWgSVh/vEnH4Vu6PpNloenpY2EXlwx88nJYnqSe5PrVyl/jakopFVKsmkun3GRr2inWZdNYT+T9iu0ufu534B+X261q3cP2i0mgB2+bGyZ9MjFK3UU9ulDRPtJWS7Gd4c0o6H4fs9MM3nfZk2eZt27vwrUpq9KdTBycnzPqFZ0em+Xr1xqXm582FYvL29MEnOa0aYfvfjQIyD4fgbxKurmQ8L/qcfKZMYD/AFxxVmfTPN1y01HzcfZ4nj8vb97djnP4VeH3hSt1oAbMsj28ixOEkZSFfGdp9ap6NpqaTpsdmrmRlyXkIwXYnJJq/wDwj6U1PvN9aAM7VdKN/cWVxFN5NxaS70fbnI/iU+xrTJpD1o7/AI0AZ2kaSNNtrmJpfOE07ynK4wGPSk0jSzpImgjnL2jSF4YmHMQPVQe4z+Vaa9KZ/H+NAFHW9NfVtPNmJzDG7AykLksoOSvtmr6IqRKigKqjAA7ClbpSj7n4UAZceleT4gl1OGbas8Qjmi28MR0bPritQU0dacOlAH//2Q==" style="width:160px; "></div>
                                    <h6 style="padding: 10px; text-align: center; font-size: 16px;" class="card-title ">LAPORAN KEMAJUAN PENYELIDIKAN DALAMAN URG / GERAN SEPADAN  
                                        URG INTERNAL RESEARCH / MATCHING GRANT PROGRESS REPORT
                                        </h6>
                                        
                                </div>
                                
                                <div class="card-header bg-transparent ">
                                
                                    <h6 style=" font-size: 16px;" class="card-title ">PANDUAN / GUIDELINE: </h6>
                                    <h6 style=" font-size: 13px;" >
                                        1.	Laporan kemajuan perlu dihantar pada setiap Jun dan Disember, dan apabila membuat.tuntutan perbelanjaan penyelidikan.
                                        Progress report must be submitted every June and December, and when claim research expense.
                                        </h6>
                                        <h6 style=" font-size: 13px;" >
                                        2.	Bagi tujuan tuntutan, PI perlu melampirkan borang BHEA.TT.12.RMC.01-01 bersama laporan kemajuan.
                                        For the purpose of claim, PI must attach BHEA.TT.12.RMC.01-01 form together with the progress report.
                                        </h6>
                                        
                                </div>
                                <div class="card-header " style="background-color:#bbb; padding: .4rem 1rem;">
                                
                                    <h6 style=" font-size: 15px;" class="card-title ">A. MAKLUMAT PROJEK / PROJECT INFORMATION </h6>
                                    
                                </div>

                                <div class="card-header bg-transparent  header-elements-inline " >
                                
                                    <h6 style=" font-size: 13px;" class="card-title ">Tajuk Projek / Project Title</h6>
                                    
                                    <div style="left: 15px; border-left: 1px solid rgba(0,0,0,.125);" class=" col-md-8 bg-transparent  header-elements-inline " >
                                
                                        <h6 style=" font-size: 13px;" class="card-title ">${doc.data().Title_Grant}</h6>
                                        
                                    </div>
                                    
                                </div>
                                <div class="card-header bg-transparent  header-elements-inline " >
                                
                                    <h6 style=" font-size: 13px;" class="card-title ">Rujukan Geran / Grant Reference</h6>
                                    
                                    <div style="left: 15px; border-left: 1px solid rgba(0,0,0,.125);" class=" col-md-8 bg-transparent  header-elements-inline " >
                                
                                        <h6 style=" font-size: 13px;" class="card-title ">${doc.data().Grant_Reference}</h6>
                                        
                                    </div>
                                    
                                </div>
                                
                                <div class="card-header bg-transparent  header-elements-inline " >
                                
                                    <h6 style=" font-size: 13px;" class="card-title ">Tempoh Projek (Bulan) / Project Duration (Month)</h6>
                                    
                                    <div style="left: 15px; border-left: 1px solid rgba(0,0,0,.125);" class=" col-md-8 bg-transparent  header-elements-inline " >
                                
                                        <h6 style=" font-size: 13px;" class="card-title ">${doc.data().Duration}</h6>
                                        
                                    </div>
                                    
                                </div>

                                <div class="card-header bg-transparent  header-elements-inline " >
                                
                                    <h6 style=" font-size: 13px;" class="card-title ">Jumlah Geran diluluskan (RM) / Approved Grant (RM)</h6>
                                    
                                    <div style="left: 15px; border-left: 1px solid rgba(0,0,0,.125);" class=" col-md-8 bg-transparent  header-elements-inline " >
                                
                                        <h6 style=" font-size: 13px;" class="card-title ">${parseFloat(doc.data().Total).toFixed(2)}</h6>
                                        
                                    </div>
                                    
                                </div>

                                <div class="card-header bg-transparent  header-elements-inline " >
                                
                                    <h6 style=" font-size: 13px;" class="card-title ">Tarikh Mula & Tamat &nbsp;&nbsp;&nbsp;&nbsp;/ Start & End Date</h6>
                                
                                    
                                    <div style="left: 15px; border-left: 1px solid rgba(0,0,0,.125);" class=" col-md-8 bg-transparent  header-elements-inline " >
                                
                                        <h6 style=" font-size: 13px;" class="card-title ">${doc.data().Start_Date + " to "+ doc.data().End_Date}</h6>
                                        
                                    </div>
                                    
                                </div>
                                <div class="card-header bg-transparent  header-elements-inline " >
                                
                                    <h6 style=" font-size: 13px;" class="card-title ">Tarikh Lanjutan diluluskan /Approved Extension Date</h6>
                                    
                                    <div style="left: 15px; border-left: 1px solid rgba(0,0,0,.125);" class=" col-md-8 bg-transparent  header-elements-inline " >
                                
                                        <h6 style=" font-size: 13px;" class="card-title ">${doc.data().Extension_Date}</h6>
                                        
                                    </div>
                                    
                                </div>

                                <div class="card-header bg-transparent  header-elements-inline " >
                                
                                    <h6 style=" font-size: 13px;" class="card-title ">Status Projek / Project Status</h6>
                                    
                                    <div style="left: 15px; border-left: 1px solid rgba(0,0,0,.125);" class=" col-md-8 bg-transparent  header-elements-inline " >
                                
                                        <h6 style=" font-size: 13px;" class="card-title ">${doc.data().Status}</h6>
                                        
                                    </div>
                                    
                                </div>
                                <div class="card-header bg-transparent  header-elements-inline " >
                                
                                    <h6 style=" font-size: 13px;" class="card-title ">Bilangan Penghantaran Laporan / Number of Report Submission </h6>
                                    
                                    <div style="left: 15px; border-left: 1px solid rgba(0,0,0,.125);" class=" col-md-8 bg-transparent  header-elements-inline " >
                                
                                        <h6 style=" font-size: 13px;" class="card-title ">${doc.data().Number_Report}</h6>
                                        
                                    </div>
                                    
                                </div>
                                </div> <div class="html2pdf__page-break"  ></div>
                                <p><br>
                                <div class="card">

                                <div class="card-header bg-transparent  header-elements-inline " >
                                
                                    <h6 style=" font-size: 13px;" class="card-title ">Nama Ketua Penyelidik & Nombor Kakitangan / Name of Principal Investigator & Staff ID </h6>
                                    
                                    <div style="left: 15px; border-left: 1px solid rgba(0,0,0,.125);" class=" col-md-8 bg-transparent  header-elements-inline " >
                                
                                        <h6 style=" font-size:13px;" class="card-title ">${doc.data().Principal_Name}</h6>
                                        <h6 style=" font-size:13px;" class="card-title ">${doc.data().Principal_ID}</h6>
                                        
                                    </div>
                                    
                                </div>

                                <div class="card-header bg-transparent  header-elements-inline " >
                                
                                    <h6 style=" font-size: 13px;" class="card-title ">Ahli Projek / Project Members</h6>
                                    
                                    <div style="left: 15px; border-left: 1px solid rgba(0,0,0,.125); " class=" col-md-8 bg-transparent  header-elements-inline " >
                                        
                                        <h6 style=" font-size: 13px;" class="card-title ">${doc.data().Project_Member}</h6>
                                        
                                    </div>
                                    
                                </div>
                                </div> <div class="html2pdf__page-break"></div><div style="padding-top:37px;"></div>
                       
                                <div class="card"  >

                            

                                <div class="card-header " style="background-color:#bbb; padding: .4rem 1rem;">
                                
                                    <h6 style="left: 15px;" class="card-title ">B. PENCAPAIAN PROJEK / PROJECT ACHIEVEMENT </h6>
                                    
                                </div>

                                <div class="card-header bg-transparent  header-elements-inline " >
                                
                                <h6 style=" font-size: 13px;" class="card-title ">Pencapaian Garis Masa / Timeline Achievement</h6>
                                
                                <div style="left: 15px; border-left: 1px solid rgba(0,0,0,.125);" class=" col-md-8 bg-transparent  header-elements-inline " >
                                    
                                    <div class="mb-4 pull-right">

                                        <ul class="list list-unstyled mb-0 text-left">
                                            <li><input type="checkbox"  checked  onclick="return false;" onkeydown="e = e || window.event; if(e.keyCode !== 9) return false;">${doc.data().Achievement_Grant}</li>
                                            
                                        </ul>
                                    </div>
                                        
                                </div>
                                
                            </div>

                                    <div class="card-header bg-transparent  header-elements-inline " >
                                        
                                    <h6 style=" font-size: 13px;" class="card-title ">Fasa Kemajuan  (sila tandakan) / Progress Phase (please tick)</h6>
                                    
                                    <div style="left: 15px; border-left: 1px solid rgba(0,0,0,.125);" class=" col-md-8 bg-transparent  header-elements-inline " >
                                        
                                        <div class="mb-4 pull-right">

                                            <ul class="list list-unstyled mb-0 text-left">
                                                <li>${doc.data().Achievement1}</li>
                                                <li>${doc.data().Achievement2}</li>
                                                <li>${doc.data().Achievement3}</li>
                                                <li>${doc.data().Achievement4}</li>
                                                <li>${doc.data().Achievement5}</li>
                                                <li>${doc.data().Achievement6}</li>
                                              
                                            </ul>
                                        </div>
                                            
                                    </div>
                                    
                                    </div>


                                    <div class="card-header " style="background-color:#bbb; padding: .4rem 1rem;">
                                
                                    <h6 style=" font-size: 15px;" class="card-title ">C. BELANJA / EXPENDITURE</h6>
                                        
                                    </div>

                                    

                                    <div  class="card-header bg-transparent   " >
                                        
                                    
                                    
                                    <div class=" col-md-8 bg-transparent  header-elements-inline   " >
                                        
                                        <table style=" width :625px; border: 1px solid rgba(0,0,0,.125);" class="table table-lg">
                                            <tr  style=" width :425px;" >
                                                <td>
                                                    <h6 style=" left: 15px; font-size: 13px;" class="mb-0">Jumlah Geran yang Diluluskan / Approved Grant </h6> 
                                                </td>
                                                <td style=" width :125px; left: 15px; border-left: 1px solid #dee2e6;"> RM ${parseFloat(doc.data().Aproved_Grant).toFixed(2)}</td>
                                                
                                            </tr>
                                            <tr style=" width :425px;">
                                                <td>
                                                <h6 style="  font-size: 13px;" class="mb-0">Jumlah yang telah diterima / Amount received</h6> 
                                            </td>
                                            <td style=" width :125px; border-left: 1px solid #dee2e6;">RM ${parseFloat(doc.data().Received_Grant).toFixed(2)}</td>
                                                
                                            </tr >
                                            <tr style=" width :425px;">
                                                <td>
                                                <h6 style="  font-size: 13px;" class="mb-0">Jumlah pembelanjaan (lampirkan dokumen sokongan yang asal) / Amount spent (attach supporting original documents)</h6> 
                                            </td>
                                            <td style=" width :125px; border-left: 1px solid #dee2e6;">RM ${parseFloat(doc.data().Total_Grant).toFixed(2)} </td>
                                            </tr>
                                            <tr style=" width :425px;">
                                                <td>
                                                <h6 style="font-size: 13px; text-align: right; left: 15px;" class="mb-0">Baki dalam simpanan / Balance in hand</h6> 
                                            </td>
                                            <td style="width :125px; border-left: 1px solid #dee2e6;">RM ${parseFloat(doc.data().Balance).toFixed(2)}</td>
                                            </tr>
                                        </tbody>
                                    </table>
                                            
                                    </div>
                                    
                                    </div>

                                    
                                </div>                                 <div class="html2pdf__page-break"></div><div style="padding-top:37px;"></div>

                                <div class="card" >

                                <div class="card-header " style="background-color:#bbb; padding: .4rem 1rem;">
                                
                                    <h6 style=" font-size: 15px;" class="card-title ">D.  SINOPSIS KEMAJUAN / SYNOPSIS OF PROGRESS</h6>
                                        
                                    </div>

                                
                                <div class="card-header bg-transparent ">
                                
                                    <h6 style=" font-size: 13px;" class="card-title ">Synopsis </h6>
                                    <h6 style=" font-size: 13px;" >${doc.data().Synopsis}
                                        </h6><br><br>
                                        <h6 style=" font-size: 13px;" >
                                        Signature & Official Stamp of Principle Investigator :

                                        <div> <img style="height: 100px;" src=" ${(doc.data().SignURL)}"></div><br>
                                        <div> <img style="height: 100px;" src=" ${(doc.data().StampURL)}"></div>

                                        </h6><br><br>
                                        </h6><br>
                                        <h6 style=" font-size: 13px; padding: .4rem 1rem;"class="card-title " >
                                          Tarikh	: ${(doc.data().Report_Date)}
                                         
                                          
                                          </h6>
                                          <h6 style=" font-size: 13px; padding: .4rem 1rem;" class="card-title " >
                                            Date : ${(doc.data().Report_Date)}
                                            </h6>
                                        
                                </div>

                                

                                
                                
                                </div>

                                <div class="html2pdf__page-break"></div><p><br>

                               
                                
                                <div  class=" card-headerr  bg-transparent " style="padding: 15px;"  >
                               
                                <h6 style="border: none;" class="card-title ">NOTA RMC / NOTE BY RMC  </h6><br>
                                <h6 style=" font-size: 13px; text-decoration-line: underline;padding: 10px;" >${(doc.data().RMC_Note)}<br><br>
                                    <h6 style=" font-size: 15px;" >
                                      Tandatangan & Cop Rasmi Ketua Penyelidik	:
                                
                                      
                                    </h6>
                                    <h6 style=" font-size: 15px;" >
                                      Signature & Official Stamp of Principle Investigator
                                      <br><br>
                                      <div> <img style="height: 100px;" src=" ${(doc.data().RMCSignURL)}"></div><br>
                                      <div> <img style="height: 100px;" src=" ${(doc.data().RMCStampURL)}"></div>
                                  
                                      </h6><br><br>
                                    <h6 style=" font-size: 15px;" >
                                      Tarikh	: ${(doc.data().RMC_AppDate)}
                                     
                                      
                                      </h6>
                                      <h6 style=" font-size: 15px;" >
                                        Date :${(doc.data().RMC_AppDate)}
                                        </h6>
                                    
                            </div>

                                
                            </div>
                        </div>
                                                                                                
                                                                                    
                            
                                                                                            `;
                                                repPdf.innerHTML = html;


                            
                           

                            document.getElementById("download")
                                .addEventListener("click", () => {
                                    const report = this.document.getElementById("invoice");
                                   // console.log(report);
                                   // console.log(window);
                                    
                                   
                                         
                                    var gen = {
                                        margin:       10,
                                        filename:     'Progress Report.pdf',
                                        image:        { type: 'jpeg', quality: 0.98 },
                                        html2canvas:  { scale: 2, logging: true, dpi: 192, letterRendering: true },
                                        jsPDF:        { unit: 'mm', format: 'a4', orientation: 'portrait' },
                                       
                                        
                                        
                                         
                                    };

                                    html2pdf().from(report).set(gen).toPdf().get('pdf').then(function (pdf) {
                                        var totalPages = pdf.internal.getNumberOfPages();
                                      
                                        for (i = 1; i <= totalPages; i++) {
                                          pdf.setPage(i);
                                          pdf.setFontSize(10);
                                          pdf.setTextColor(150);
                                          pdf.text('BHEASB.TT.11.RMC.02-01' + i , pdf.internal.pageSize.getWidth() - 60, pdf.internal.pageSize.getHeight() - 285);

                                          pdf.text('' + i , pdf.internal.pageSize.getWidth() - 105, pdf.internal.pageSize.getHeight() - 10);
                                          pdf.text('Effective Date : 1 Disember 2020'  , pdf.internal.pageSize.getWidth() - 67, pdf.internal.pageSize.getHeight() - 5);
                                        } 
                                      }).save();
                                      

                                    

                                  
                                 
                                    
                                })
    
          });

	}else{
		console.log('user logged out');
	}
});



    
  
        
       
    }




   


//---------------------------------------Auth state Changed--------------------------------------------------------------------------//
auth.onAuthStateChanged(user => {
	if (user) {
		
		User = user;	
	

	}else{
		console.log('user logged out');
	}
});
//---------------------------------------Log Out Account--------------------------------------------------------------------------//
 
           
LogOut.addEventListener('click', function(e) {
    e.preventDefault();
    auth.signOut().then(() => {
        (e => alert(e.message));
        alert("Sign Out" );	
        window.location.href = 'home.html';
    })			
                        
                        
            });